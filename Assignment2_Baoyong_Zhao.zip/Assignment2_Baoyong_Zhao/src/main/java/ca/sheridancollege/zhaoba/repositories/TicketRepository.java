package ca.sheridancollege.zhaoba.repositories;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import ca.sheridancollege.zhaoba.beans.Ticket;
import lombok.AllArgsConstructor;

@Repository
@AllArgsConstructor
public class TicketRepository {
	
	private NamedParameterJdbcTemplate jdbc;
	
	public void addTicket(Ticket ticket) {
		
		MapSqlParameterSource parameters= new MapSqlParameterSource();
		
		String query = "INSERT INTO ticket_table (user_name,user_gender,price,seat_zone,seat_row,seat_number,user_email) VALUES "
				+"(:na,:ge,:pr,:zo,:ro,:sn,:em)"; //name parameter, placeholder;
		
		parameters.addValue("na",ticket.getName());
		parameters.addValue("ge",ticket.getGender());
		parameters.addValue("pr",ticket.getPrice());
		parameters.addValue("zo",ticket.getZone());
		parameters.addValue("ro",ticket.getRow());
		parameters.addValue("sn",ticket.getSeatnum());
		parameters.addValue("em",ticket.getEmail());
		
		jdbc.update(query,parameters);
		
	}

	public ArrayList<Ticket> getTickets() {
		MapSqlParameterSource parameters= new MapSqlParameterSource();
		ArrayList<Ticket> tickets = new ArrayList<Ticket>();
		String query = "Select * from ticket_table";
		List<Map<String, Object>> rows = jdbc.queryForList(query, parameters);
		
		for (Map<String, Object> row: rows) {
			Ticket t = new Ticket();
			t.setId((int)row.get("id"));
			t.setName((String)row.get("user_name"));
			t.setGender((String)row.get("user_gender"));
			t.setPrice((double)row.get("price"));
			t.setZone((String)row.get("seat_zone"));
			t.setRow((int)row.get("seat_row"));
			t.setSeatnum((int)row.get("seat_number"));
			t.setEmail((String)row.get("user_email"));
			
			//Make sure to add the object into the list.
			tickets.add(t);
		}
		
		return tickets;
	}
	
	
	public ArrayList<Ticket> getTickets2() {
		MapSqlParameterSource parameters= new MapSqlParameterSource();

		String query = "Select * from ticket_table";
		
		ArrayList<Ticket> tickets = (ArrayList<Ticket>)jdbc.query(query, parameters, new BeanPropertyRowMapper<Ticket>(Ticket.class));

		
		return tickets;
	}
	
	public Ticket findById(int id) {
		MapSqlParameterSource parameters= new MapSqlParameterSource();
		ArrayList<Ticket> tickets = new ArrayList<Ticket>();
		parameters.addValue("meow", id);
		String query = "Select * from ticket_table where id=:meow";
		List<Map<String, Object>> rows = jdbc.queryForList(query, parameters);
		
		for (Map<String, Object> row: rows) {
			Ticket t = new Ticket();
			t.setId((int)row.get("id"));
			t.setName((String)row.get("user_name"));
			t.setGender((String)row.get("user_gender"));
			t.setPrice((double)row.get("price"));
			t.setZone((String)row.get("seat_zone"));	
			System.out.println("seat_row: "+row.get("seat_row"));
            t.setRow((int)row.get("seat_row"));
            
            t.setSeatnum((int)row.get("seat_number"));      
			t.setEmail((String)row.get("user_email"));
			
			//Make sure to add the object into the list.
			tickets.add(t);
		}
		
		if(tickets.size()>0)
			return tickets.get(0);
		else
			return null;
	}
	
	
	public Ticket findById_2(int id) {
		MapSqlParameterSource parameters= new MapSqlParameterSource();

		parameters.addValue("meow", id);
		String query = "Select * from ticket_table where id=:meow";
		
		ArrayList<Ticket> tickets = (ArrayList<Ticket>)jdbc.query(query, parameters, new BeanPropertyRowMapper<Ticket>(Ticket.class));

		
		if(tickets.size()>0)
			return tickets.get(0);
		else
			return null;
	}
	
public void editTicket(Ticket ticket) {
		
		MapSqlParameterSource parameters= new MapSqlParameterSource();
		 
		String query = "UPDATE ticket_table SET "
				+"user_name=:na, user_gender=:ge,price=:pr,seat_zone=:zo,seat_row=:ro,seat_number=:sn,user_email=:em "
				+ "where id=:id"; //name parameter, placeholder;
		
		// Don't put the ":" in the parameters.
		// Must provide a mapping for all named parameters.
		
		parameters.addValue("id",ticket.getId());
		parameters.addValue("na",ticket.getName());
		parameters.addValue("ge",ticket.getGender());
		parameters.addValue("pr",ticket.getPrice());
		parameters.addValue("zo",ticket.getZone());
		parameters.addValue("ro",ticket.getRow());
		parameters.addValue("sn",ticket.getSeatnum());
		parameters.addValue("em",ticket.getEmail());

		
		jdbc.update(query,parameters);
		
	}
	
	public void deleteTicket(Ticket ticket) {
		
		MapSqlParameterSource parameters= new MapSqlParameterSource();
		
	
		String query = "DELETE FROM ticket_table "
				+ "WHERE id=:id"; //name parameter, placeholder;
		
		parameters.addValue("id",ticket.getId());
		
	
		jdbc.update(query,parameters);
		
	}
	
}
