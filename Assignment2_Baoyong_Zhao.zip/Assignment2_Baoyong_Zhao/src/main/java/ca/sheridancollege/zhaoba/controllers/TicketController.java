package ca.sheridancollege.zhaoba.controllers;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;

import ca.sheridancollege.zhaoba.beans.Ticket;
import ca.sheridancollege.zhaoba.repositories.TicketRepository;
import lombok.AllArgsConstructor;

@Controller
@AllArgsConstructor
public class TicketController {
	
	private TicketRepository ticketRepo;
	
	@GetMapping("/")
	public String goRoot() {
		return "root.html";
	}
	
	@GetMapping("/add")
	public String goRoot(Model model){
		model.addAttribute("ticket", new Ticket());	
		return "add.html";
	}
	
	@GetMapping("/processticket")
	public String process(@ModelAttribute Ticket ticket, Model model) {
	model.addAttribute("ticket", new Ticket());	
		ticketRepo.addTicket(ticket);
		return "Add.html";
	}
	
	
	
	@GetMapping("/view")
	public String viewTicket(Model model) {
		
		ArrayList<Ticket> tickets = ticketRepo.getTickets();
		
			model.addAttribute("tickets", tickets);
			return "view.html";		
	}

	@GetMapping("/stat")
	public String viewStat(Model model) {
		
		ArrayList<Ticket> tickets = ticketRepo.getTickets();
		
		ArrayList<Integer>stat = new ArrayList<Integer>();
		stat.add(tickets.size());
		int num_male=0;
		int num_female=0;
		float total_price=0;
		int num_East=0;
		int num_South=0;
		int num_West=0;
		int num_North=0;
		for(Ticket t:tickets) {
			total_price+=t.getPrice();
			if (t.getGender()!= null && t.getGender().trim().equalsIgnoreCase("M")) {num_male+=1;}
			else if(t.getGender()!= null && t.getGender().trim().equalsIgnoreCase("F")) {
				num_female+=1;
			}
			switch(t.getZone()) {
			case "E": 
				num_East+=1;
				break;
			case "S": 
				num_South+=1;
				break;
			case "W": 
				num_West+=1;
				break;
			case "N": 
				num_North+=1;
				break;
			
			}
		}
		
		stat.add(num_male);
		stat.add(num_female);
		stat.add((int)total_price);
		stat.add(num_East);
		stat.add(num_South);
		stat.add(num_West);
		stat.add(num_North);
		stat.add((int)(total_price/tickets.size()));
		
		
			model.addAttribute("stat", stat);
			return "stat.html";		
	}
	
	@GetMapping("/edit/{id}")
	public String editRecord(@PathVariable int id, Model model) {
	Ticket t = ticketRepo.findById(id);
	model.addAttribute("ticket",t);
	return "editTicket.html";
	
	}
	
	@GetMapping("/edit")
	public String EidtTicket(@ModelAttribute Ticket ticket, Model model) {
		
		ticketRepo.editTicket(ticket);
		return "redirect:/view";
	}
	
	@GetMapping("/delete/{id}")
	public String deleteTicket(@PathVariable int id, Model model) {
		Ticket t = ticketRepo.findById(id);
		ticketRepo.deleteTicket(t);
		return "redirect:/view";
	}
	
}
