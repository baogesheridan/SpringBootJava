package ca.sheridancollege.zhaoba;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment2BaoyongZhaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Assignment2BaoyongZhaoApplication.class, args);
	}

}
