CREATE TABLE ticket_table (
	id int not null primary key auto_increment, 
	user_name VARCHAR(16), 
	user_gender char(2), 
	price double, 
	seat_zone varchar(6), 
	seat_row int, 
	seat_number int, 
	user_email VARCHAR(30)
	);