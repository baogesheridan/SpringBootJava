package ca.sheridancollege.zhaoba;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assignment2BaoyongZhaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
