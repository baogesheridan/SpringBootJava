CREATE TABLE TemperatureRecord (
  id            BIGINT NOT NULL PRIMARY KEY AUTO_INCREMENT,
  tDate             Date NOT NULL,
  temperature          Double not null,
  city	VARCHAR(45) NOT NULL,
  province	VARCHAR(45) NOT NULL
);


