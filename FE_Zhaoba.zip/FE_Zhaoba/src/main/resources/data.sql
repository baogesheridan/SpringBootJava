INSERT INTO TemperatureRecord (tDate, temperature, city, province)
VALUES ('2024-08-14', 27, 'Toronto', 'Ontario');

INSERT INTO TemperatureRecord (tDate, temperature, city, province)
VALUES ('2024-08-15', 22, 'Vancouver', 'British Columbia');

INSERT INTO TemperatureRecord (tDate, temperature, city, province)
VALUES ('2024-08-16', 30, 'Calgary', 'Alberta');

INSERT INTO TemperatureRecord (tDate, temperature, city, province)
VALUES ('2024-08-17', 25, 'Montreal', 'Quebec');

INSERT INTO TemperatureRecord (tDate, temperature, city, province)
VALUES ('2024-08-18', 20, 'Halifax', 'Nova Scotia');


