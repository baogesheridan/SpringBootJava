package ca.sheridancollege.zhaoba;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeZhaobaApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeZhaobaApplication.class, args);
	}

}
