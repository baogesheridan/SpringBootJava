package ca.sheridancollege.zhaoba.beans;



import java.sql.Date;

import org.springframework.lang.NonNull;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor

public class TemperatureRecord {
	private Long id;
	@NonNull
	private Date tDate;
	@NonNull
	private Double temperature;
	@lombok.NonNull
	private String city;
	@lombok.NonNull
	private String province;

}
