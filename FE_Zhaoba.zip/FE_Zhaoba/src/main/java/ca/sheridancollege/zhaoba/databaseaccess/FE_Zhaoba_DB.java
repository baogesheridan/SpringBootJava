package ca.sheridancollege.zhaoba.databaseaccess;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import ca.sheridancollege.zhaoba.beans.AverageTemperature;
import ca.sheridancollege.zhaoba.beans.TemperatureRecord;

@Repository
public class FE_Zhaoba_DB {

    @Autowired
    private NamedParameterJdbcTemplate jdbc;

    // insert a temperature record
    public void addRecord(TemperatureRecord temperature) {
        // Check if a TemperatureRecord with the same date, city, and province already exists
        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        String checkQuery = "SELECT COUNT(*) FROM TemperatureRecord WHERE tDate = :tDate AND city = :city AND province = :province";
        namedParameters.addValue("tDate", temperature.getTDate());
        namedParameters.addValue("city", temperature.getCity());
        namedParameters.addValue("province", temperature.getProvince());
        int count = jdbc.queryForObject(checkQuery, namedParameters, Integer.class);

        if (count > 0) {
            throw new DuplicateKeyException("This temperature record already exists.");
        }

        // If no duplicate found, proceed with insertion
        MapSqlParameterSource parameters = new MapSqlParameterSource();
        String query = "INSERT INTO TemperatureRecord (tDate, temperature, city, province) VALUES (:td, :te, :ci, :pr)";
        parameters.addValue("td", temperature.getTDate());
        parameters.addValue("te", temperature.getTemperature());
        parameters.addValue("ci", temperature.getCity());
        parameters.addValue("pr", temperature.getProvince());
        jdbc.update(query, parameters);
    }

    // get all temperature records
    public List<TemperatureRecord> getRecords() {
        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        String query = "SELECT * FROM TemperatureRecord";
        try {
            return jdbc.query(query, namedParameters, new BeanPropertyRowMapper<TemperatureRecord>(TemperatureRecord.class));
        } catch (EmptyResultDataAccessException erdae) {
            return new ArrayList<>();
        }
    }
    
 // search Records by city
 	public List<TemperatureRecord> findRecordsByCity(String city) {
 	    MapSqlParameterSource namedParameters = new MapSqlParameterSource();
 	    String query = "SELECT * FROM TemperatureRecord WHERE city = :city";
 	    namedParameters.addValue("city", city);
 	    try {
 	        return jdbc.query(query, namedParameters, new BeanPropertyRowMapper<TemperatureRecord>(TemperatureRecord.class));
 	    } catch (EmptyResultDataAccessException erdae) {
 	        return new ArrayList<>();
 	    }
 	}


 	public List<AverageTemperature> calculateAverageTemperature() {
 	    String query = "SELECT city, AVG(temperature) AS averageTemperature FROM TemperatureRecord GROUP BY city";
 	    return jdbc.query(query, new MapSqlParameterSource(), 
 	            new BeanPropertyRowMapper<>(AverageTemperature.class));
 	}

 	public List<AverageTemperature> getAverageTemperature(String city) {
 	    MapSqlParameterSource namedParameters = new MapSqlParameterSource();
 	    String query = "SELECT city, AVG(temperature) AS averageTemperature FROM TemperatureRecord WHERE city = :city GROUP BY city";
 	    namedParameters.addValue("city", city);
 	    return jdbc.query(query, namedParameters, new BeanPropertyRowMapper<>(AverageTemperature.class));
 	}


    
    
}
