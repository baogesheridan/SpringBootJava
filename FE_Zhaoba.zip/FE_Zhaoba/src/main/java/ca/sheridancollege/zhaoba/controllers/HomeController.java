package ca.sheridancollege.zhaoba.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import ca.sheridancollege.zhaoba.beans.AverageTemperature;
import ca.sheridancollege.zhaoba.beans.TemperatureRecord;
import ca.sheridancollege.zhaoba.databaseaccess.FE_Zhaoba_DB;

@Controller
public class HomeController {

    @Autowired
    private FE_Zhaoba_DB da;

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("newRecord", new TemperatureRecord());
        return "index";
    }

    @PostMapping("/add")
    public String addProcess(Model model, @ModelAttribute TemperatureRecord record) {
        
    	try {
            da.addRecord(record);
            model.addAttribute("successMessage", "Record added successfully!");
        } catch (DuplicateKeyException e) {
            model.addAttribute("errorMessage", e.getMessage());
        }
        
    	System.out.println("add Process method");
        List<TemperatureRecord> records = da.getRecords();
        model.addAttribute("records", records);
        model.addAttribute("newRecord", new TemperatureRecord());
        
        return "index";
    }
    
	@GetMapping("/search")
	public String searchRecordByCity(Model model) {
		model.addAttribute("newRecord", new TemperatureRecord());	
		return "searchByCity";
	}
	
	@PostMapping("/search")
	public String showRecordbyId(Model model, @ModelAttribute TemperatureRecord record) {
	    List<TemperatureRecord> records = da.findRecordsByCity(record.getCity());
	    if (records.isEmpty()) {
	        model.addAttribute("nullMessage", record.getCity() + " has no records in the database.");
	    } else {
	        model.addAttribute("records", records);
	    }
        model.addAttribute("newRecord", new TemperatureRecord());
        return "searchByCity";
	}
	
	
	@GetMapping("/average")
	public String searchAverageRecordByCity(Model model) {
		model.addAttribute("newRecord", new TemperatureRecord());	
		return "averageTemperature";
	}
	
	@PostMapping("/average")
	public String showAverageTemperature(Model model, @ModelAttribute TemperatureRecord record) {
	    List<AverageTemperature> records = da.getAverageTemperature(record.getCity());
	    if (records.isEmpty()) {
	        model.addAttribute("nullMessage", record.getCity() + " has no records in the database.");
	    } else {
	        model.addAttribute("records", records);
	    }
	    model.addAttribute("newRecord", new TemperatureRecord());
	    return "averageTemperature";
	}

    
    
}
