package ca.sheridancollege.zhaoba.beans;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AverageTemperature {
	private String city;
	private Double averageTemperature;

}
