INSERT INTO sec_user (email, encryptedPassword, enabled)
VALUES ('le@sheridancollege.ca', '$2a$10$1ltibqiyyBJMJQ4hqM7f0OusP6np/IHshkYc4TjedwHnwwNChQZCy', 1);

INSERT INTO sec_user (email, encryptedPassword, enabled)
VALUES ('admin@sheridancollege.ca', '$2a$10$PrI5Gk9L.tSZiW9FXhTS8O8Mz9E97k2FZbFvGFFaSsiTUIl.TCrFu', 1);

INSERT INTO sec_user (email, encryptedPassword, enabled)
VALUES ('guest@sheridancollege.ca', '$2a$10$1ltibqiyyBJMJQ4hqM7f0OusP6np/IHshkYc4TjedwHnwwNChQZCy', 1);

 
INSERT INTO sec_role (roleName)
VALUES ('ROLE_USER');

INSERT INTO sec_role (roleName)
VALUES ('ROLE_ADMIN');
 
INSERT INTO sec_role (roleName)
VALUES ('ROLE_GUEST');
 

 
INSERT INTO user_role (userId, roleId)
VALUES (1, 1);
 
INSERT INTO user_role (userId, roleId)
VALUES (2, 2);

INSERT INTO user_role (userId, roleId)
VALUES (3, 3);


INSERT INTO author (firstName,lastName)
VALUES ('Bill', 'Zhao');

INSERT INTO author (firstName,lastName)
VALUES ('John', 'Smith');

INSERT INTO author (firstName,lastName)
VALUES ('Ming', 'Park');


INSERT INTO book (title,isbn)
VALUES ('Blue Sky', '1234');

INSERT INTO book (title,isbn)
VALUES ('Sun Rise', '1235');

INSERT INTO book (title,isbn)
VALUES ('Holiday', '1236');

INSERT INTO authorbook (authorId, bookId)
VALUES (1, 1);
INSERT INTO authorbook (authorId, bookId)
VALUES (1, 2);
INSERT INTO authorbook (authorId, bookId)
VALUES (2, 1);
INSERT INTO authorbook (authorId, bookId)
VALUES (3, 1);
INSERT INTO authorbook (authorId, bookId)
VALUES (2, 3);