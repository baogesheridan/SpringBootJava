package ca.sheridancollege.zhaoba.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ca.sheridancollege.zhaoba.beans.Author;
import ca.sheridancollege.zhaoba.beans.Book;
import ca.sheridancollege.zhaoba.database.DatabaseAccess;

@Controller
public class HomeController {

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private DatabaseAccess da;

	@GetMapping("/")
	public String index() {
		return "index";
	}

	@GetMapping("/secure")
	public String secureindex() {
		return "/secure/index";
	}
	
    @GetMapping("/search")
    public String searchIndex(Model model) {
        model.addAttribute("mybook", new Book());
        model.addAttribute("myauthor", new Author());
        model.addAttribute("searchPerformed", false);
		return "/secure/booksearch";
	}
    

    @PostMapping("/searchByIsbn")
    public String searchByIsbn(@RequestParam String isbn, Model model) {
        Book foundBook = null;
        List<Book> books = new ArrayList<>();

        if (isbn != null && !isbn.isEmpty()) {
            foundBook = da.searchBookByIsbn(isbn);
        }

        if (foundBook != null) {
            books.add(foundBook);
        }

        model.addAttribute("books", books);
        model.addAttribute("searchPerformed", true);
        return "/secure/booksearch";
    }

    @PostMapping("/searchByFirstName")
    public String searchByFirstName(@RequestParam String firstName, Model model) {
        List<Book> foundBooks = new ArrayList<>();

        if (firstName != null && !firstName.isEmpty()) {
            foundBooks = da.searchBookByAuthor(firstName);
        }

        model.addAttribute("books", foundBooks);
        model.addAttribute("searchPerformed", true);
        return "/secure/booksearch";
    }
	

	@GetMapping("/searchByIsbn")
	public String booksearch() {
		Book book = da.searchBookByIsbn("1234");
		System.out.println("Book: " + book);
		return "/secure/index";
	}

	@GetMapping("/searchByFirstName")
	public String bookSearchByAuthor(Model model) {
		List<Book> books = da.searchBookByAuthor("Bill");

		if (books != null) {
			for (Book book : books) {
				System.out.println("Book: " + book);
			}
		}

		model.addAttribute("books", books);
		return "/secure/index";
	}
	
    @GetMapping("/addBook")
    public String addBookIndex(Model model) {
        model.addAttribute("mybook", new Book());
	    return "/secure2/addbook";
    }
	
    @PostMapping("/addBook")
    public String addBookProcess(@ModelAttribute Book book, Model model) {
        try {
            da.addBook(book);
            model.addAttribute("successMessage", "Book added successfully!");
        } catch (DuplicateKeyException e) {
            model.addAttribute("errorMessage", e.getMessage());
        }
        List<Book> books = da.getBooks();
        model.addAttribute("books", books);
        model.addAttribute("mybook", new Book());
	    return "/secure2/addbook";
	}
    
    @GetMapping("/addAuthor")
    public String addAuthorIndex(Model model) {
        model.addAttribute("myauthor", new Author());
	    return "/secure2/addauthor";
    }
	
    @PostMapping("/addAuthor")
    public String addAuthorProcess(@ModelAttribute Author author, Model model) {
        try {
            da.addAuthor(author);
            model.addAttribute("successMessage", "Author added successfully!");
        } catch (DuplicateKeyException e) {
            model.addAttribute("errorMessage", e.getMessage());
        }
        List<Author> authors = da.getAuthors();
        model.addAttribute("authors", authors);
        model.addAttribute("myauthor", new Author());
	    return "/secure2/addauthor";
	}
    
    @GetMapping("/addAuthorBook")
	public String addAuthorBookIndex(Model model) {
		model.addAttribute("inputauthoridandbookid", false);
		model.addAttribute("processed", false);
		return "/secure2/addauthorbook";
	}

	@PostMapping("/addAuthorBookProcess")
	public String AuthorBookProcess(@RequestParam Long authorId, @RequestParam Long bookId, Model model) {
		String addmessage = "";
		System.out.println("author: " + authorId);
		if (da.checkAuthorBook(authorId, bookId)) {
			addmessage = "AuthorBook already exists!";
		} else {
			if (da.checkBookByBookId(bookId) && da.checkAuthorByAuthorId(authorId)) {
				da.addAuthorBook(authorId, bookId);
				addmessage = "AuthorBook with authodId: "+authorId+" and bookId: " + bookId+ " added successfully!";
				model.addAttribute("inputauthoridandbookid", true);
				model.addAttribute("mybook", da.searchBookByBookId(bookId));
				model.addAttribute("myauthor", da.searchAuthorByAuthorId(authorId));
			} else if (!da.checkBookByBookId(bookId) && da.checkAuthorByAuthorId(authorId)) {
				addmessage = "BookId " + bookId + " does not exist!";
			} else if (da.checkBookByBookId(bookId) && !da.checkAuthorByAuthorId(authorId)) {
				addmessage = "AuthorId " + authorId + " does not exist!";
			} else {
				addmessage = "AuthorId " + authorId + "and BookId " + bookId + " both do not exist!";
			}
			;
		}

		model.addAttribute("processed", true);
		model.addAttribute("addmessage", addmessage);
		return "/secure2/addauthorbook";
	}
	

	@GetMapping("/login")
	public String login() {
		return "login";
	}

	@GetMapping("/permission-denied")
	public String permissionDenied() {
		return "/error/permission-denied";
	}

	// create new password
	@GetMapping("/pass")
	public String pass() {
		String password = passwordEncoder.encode("1234").toString();
		String aPassword = passwordEncoder.encode("123").toString();
		System.out.println("encoded password=" + password);
		System.out.println("encoded password=" + aPassword);
		boolean m = passwordEncoder.matches(password, aPassword);
		System.out.println("Compared two password = " + m);
		return "index";
	}
}
