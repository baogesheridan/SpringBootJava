package ca.sheridancollege.zhaoba.beans;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Book {
	private Long bookId;
	private String title;
	private String isbn;

}
