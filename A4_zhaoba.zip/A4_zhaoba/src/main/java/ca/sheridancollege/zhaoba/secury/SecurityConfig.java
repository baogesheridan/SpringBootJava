package ca.sheridancollege.zhaoba.secury;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import static org.springframework.security.web.util.matcher.AntPathRequestMatcher.antMatcher;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

	@Autowired
	private LoggingAccessDeniedHandler accessDeniedHandler;
	@Autowired
	private UserDetailsService userDetailsService;

	/*
	@Bean
	public UserDetailsService userDetailsService(PasswordEncoder passwordEncoder) {

		UserDetails user = User.withUsername("le@sheridancollege.ca").password(passwordEncoder.encode("1234"))
				.roles("USER").build();
		UserDetails guest = User.withUsername("guest@guest.com").password(passwordEncoder.encode("password"))
				.roles("GUEST").build();
		return new InMemoryUserDetailsManager(user, guest);
	}
	*/
	

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

        http.csrf(c -> c.disable()).headers(header -> header.frameOptions(frame -> frame.disable()))
            .authorizeHttpRequests(requests -> requests
                .requestMatchers(antMatcher("/"), antMatcher("/index"), antMatcher("/js/**"), antMatcher("/css/**"),
                    antMatcher("/images/**"), antMatcher("/permission-denied")).permitAll()
                .requestMatchers(antMatcher("/secure/**")).hasAnyRole("USER", "ADMIN")
                .requestMatchers(antMatcher("/secure2/**")).hasRole("ADMIN")
                .requestMatchers(antMatcher("/search")).hasAnyRole("USER", "ADMIN")
                .requestMatchers(antMatcher("/searchByIsbn")).hasAnyRole("USER", "ADMIN")
                .requestMatchers(antMatcher("/searchByFirstName")).hasAnyRole("USER", "ADMIN")
                .requestMatchers(antMatcher("/addBook")).hasRole("ADMIN")
                .requestMatchers(antMatcher("/addAuthor")).hasRole("ADMIN")
                .requestMatchers(antMatcher("/addAuthorBook")).hasRole("ADMIN")
                .requestMatchers(antMatcher("/addAuthorBookProcess")).hasRole("ADMIN")
                .requestMatchers(antMatcher("/h2-console/**")).permitAll()
                .anyRequest().denyAll())
            .formLogin(form -> form.loginPage("/login").loginProcessingUrl("/login")
                .defaultSuccessUrl("/secure", true).permitAll())
            .exceptionHandling(exception -> exception.accessDeniedHandler(accessDeniedHandler))
            .logout(logout -> logout.invalidateHttpSession(true).clearAuthentication(true).logoutUrl("/logout")
                .logoutSuccessUrl("/login?logout").permitAll());
        return http.build();
    }

	@Bean
	public PasswordEncoder passwordEncoder() {
		PasswordEncoder encoder = new BCryptPasswordEncoder();
		return encoder;
	}

}
