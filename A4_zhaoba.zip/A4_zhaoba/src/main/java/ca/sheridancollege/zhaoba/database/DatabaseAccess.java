package ca.sheridancollege.zhaoba.database;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Repository;

import ca.sheridancollege.zhaoba.beans.User;
import ca.sheridancollege.zhaoba.beans.Author;
import ca.sheridancollege.zhaoba.beans.Book;

@Repository
public class DatabaseAccess {
	@Autowired
	private NamedParameterJdbcTemplate jdbc;

	// search book by isbn;
	public Book searchBookByIsbn(String isbn) {
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		String query = "SELECT * FROM book WHERE isbn = :isbn";
		namedParameters.addValue("isbn", isbn);
		try {
			return jdbc.queryForObject(query, namedParameters, new BeanPropertyRowMapper<>(Book.class));
		} catch (EmptyResultDataAccessException erdae) {
			return null;
		}
	}
	
	// search book by first name of author
	public List<Book> searchBookByAuthor(String firstName) {
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		String query = "SELECT * FROM book WHERE bookId IN (" + "SELECT bookId FROM author "
				+ "JOIN authorbook ON author.authorId = authorbook.authorId " + "WHERE firstName = :firstName)";
		namedParameters.addValue("firstName", firstName);
		try {
			return jdbc.query(query, namedParameters, new BeanPropertyRowMapper<>(Book.class));
		} catch (EmptyResultDataAccessException erdae) {
			return null;
		}
	}
	
	// add a book;
		public void addBook(Book book) {
		    // Check if a book with the same name already exists
		    MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		    String checkQuery = "SELECT COUNT(*) FROM book WHERE isbn = :isbn";
		    namedParameters.addValue("isbn", book.getIsbn());
		    int count = jdbc.queryForObject(checkQuery, namedParameters, Integer.class);

		    if (count > 0) {
		        throw new DuplicateKeyException("Book with the isbn: " + book.getIsbn() + " already exists.");
		    }

		    // If no duplicate found, proceed with insertion
		    MapSqlParameterSource parameters = new MapSqlParameterSource();
		    String query = "INSERT INTO book (title, isbn) VALUES (:ti, :is)";
		    parameters.addValue("ti", book.getTitle());
		    parameters.addValue("is", book.getIsbn());
		    jdbc.update(query, parameters);
		}
		
		// get books
		public List<Book> getBooks() {
		    MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		    String query = "SELECT * FROM book";
		    try {
		        return jdbc.query(query, namedParameters, new BeanPropertyRowMapper<Book>(Book.class));
		    } catch (EmptyResultDataAccessException erdae) {
		        return new ArrayList<>();
		    }
		}
		
		 // check if authorbook already exist
	    public boolean checkAuthorBook(Long authorId, Long bookId) {
	        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
	        String checkQuery = "SELECT COUNT(*) FROM authorbook WHERE authorId = :ai AND bookId = :bi";
	        namedParameters.addValue("ai", authorId);
	        namedParameters.addValue("bi", bookId);
	        int count = jdbc.queryForObject(checkQuery, namedParameters, Integer.class);

	        if (count > 0) {
	            return true;
	        }
	        else {
	        	return false;
	        }
	    }
	    
	    // Add an author-book relationship
	    public void addAuthorBook(Long authorId, Long bookId) { 	
	        MapSqlParameterSource parameters = new MapSqlParameterSource();
	        String query = "INSERT INTO authorbook (authorId, bookId) VALUES (:authorId, :bookId)";
	        parameters.addValue("authorId", authorId);
	        parameters.addValue("bookId", bookId);
	        jdbc.update(query, parameters);
	    }
	    
	    // Check if author exists by author ID
	    public boolean checkAuthorByAuthorId(Long authorId) {
	        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
	        String checkQuery = "SELECT COUNT(*) FROM author WHERE authorId = :authorId";
	        namedParameters.addValue("authorId", authorId);
	        int count = jdbc.queryForObject(checkQuery, namedParameters, Integer.class);
	        if(count > 0) {
	        	return true;
	        }
	        else{
	        	return false;}
	    }
	    
	    // Check if book exists by book ID
	    public boolean checkBookByBookId(Long bookId) {
	        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
	        String checkQuery = "SELECT COUNT(*) FROM book WHERE bookId = :bookId";
	        namedParameters.addValue("bookId", bookId);
	        int count = jdbc.queryForObject(checkQuery, namedParameters, Integer.class);
	        if(count > 0) {
	        	return true;
	        }
	        else{
	        	return false;}
	    }
	    
	    // Search book by book id
	    public Book searchBookByBookId(Long bookId) {
	        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
	        String query = "SELECT * FROM book WHERE bookId = :bookId";
	        namedParameters.addValue("bookId", bookId);
	        try {
	            return jdbc.queryForObject(query, namedParameters, new BeanPropertyRowMapper<>(Book.class));
	        } catch (EmptyResultDataAccessException erdae) {
	            return null;
	        }
	    }
	    
	    // search author by author id
	    public Author searchAuthorByAuthorId(Long authorId) {
	        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
	        String query = "SELECT * FROM author WHERE authorId = :authorId";
	        namedParameters.addValue("authorId", authorId);
	        try {
	            return jdbc.queryForObject(query, namedParameters, new BeanPropertyRowMapper<>(Author.class));
	        } catch (EmptyResultDataAccessException erdae) {
	            return null;
	        }
	    }
		
		// add a Author;
				public void addAuthor(Author author) {
				    // Check if a book with the same name already exists
				    MapSqlParameterSource namedParameters = new MapSqlParameterSource();
				    String checkQuery = "SELECT COUNT(*) FROM author WHERE firstName = :fn and lastName= :ln";
				    namedParameters.addValue("fn", author.getFirstName());
				    namedParameters.addValue("ln", author.getLastName());
				    int count = jdbc.queryForObject(checkQuery, namedParameters, Integer.class);

				    if (count > 0) {
				        throw new DuplicateKeyException("Author with the firstName: " + author.getFirstName() + " and lastName: " + author.getLastName() + " already exists.");
				    }

				    // If no duplicate found, proceed with insertion
				    MapSqlParameterSource parameters = new MapSqlParameterSource();
				    String query = "INSERT INTO author (firstName,lastName) VALUES (:fn, :ln)";
				    parameters.addValue("fn", author.getFirstName());
				    parameters.addValue("ln", author.getLastName());
				    jdbc.update(query, parameters);
				}
				
				// get authors
				public List<Author> getAuthors() {
				    MapSqlParameterSource namedParameters = new MapSqlParameterSource();
				    String query = "SELECT * FROM author";
				    try {
				        return jdbc.query(query, namedParameters, new BeanPropertyRowMapper<Author>(Author.class));
				    } catch (EmptyResultDataAccessException erdae) {
				        return new ArrayList<>();
				    }
				}

	public User findUserAccount(String email) {
		// this object is used to hold the parameter value for the query
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		String query = "SELECT * FROM sec_user where email = :email";
		namedParameters.addValue("email", email);
		try {
			// use jdbc to run the query with parameters and BeanPropertyRomMapper to return
			// User object;
			return jdbc.queryForObject(query, namedParameters, new BeanPropertyRowMapper<User>(User.class));
		} catch (EmptyResultDataAccessException erdae) {
			return null;
		}
	}

	public List<String> getRolesById(Long userId) {
		// this object is used to hold the parameter value for the query
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		String query = "SELECT sec_role.roleName " + "FROM user_role, sec_role "
				+ "WHERE user_role.roleId = sec_role.roleId " + "AND userId = :userId";
		// add the userId to the query
		namedParameters.addValue("userId", userId);
		// run the query with Jdbc object and with userId parameter, and String.class
		// for mapping
		return jdbc.queryForList(query, namedParameters, String.class);
	}

}
