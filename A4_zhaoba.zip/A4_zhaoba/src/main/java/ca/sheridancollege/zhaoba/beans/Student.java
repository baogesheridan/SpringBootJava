package ca.sheridancollege.zhaoba.beans;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Student {

}
